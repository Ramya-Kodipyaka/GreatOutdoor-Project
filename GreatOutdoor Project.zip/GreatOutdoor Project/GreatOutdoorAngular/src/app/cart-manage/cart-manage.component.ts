import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cart-manage',
  templateUrl: './cart-manage.component.html',
  styleUrls: ['./cart-manage.component.css']
})
export class CartManageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
