import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchproductbyproductnameComponent } from './searchproductbyproductname.component';

describe('SearchproductbyproductnameComponent', () => {
  let component: SearchproductbyproductnameComponent;
  let fixture: ComponentFixture<SearchproductbyproductnameComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SearchproductbyproductnameComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchproductbyproductnameComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
