import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-wish-manage',
  templateUrl: './wish-manage.component.html',
  styleUrls: ['./wish-manage.component.css']
})
export class WishManageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
