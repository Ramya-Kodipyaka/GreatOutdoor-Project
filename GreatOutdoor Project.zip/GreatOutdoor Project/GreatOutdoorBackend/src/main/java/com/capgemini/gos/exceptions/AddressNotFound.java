package com.capgemini.gos.exceptions;

@SuppressWarnings("serial")
public class AddressNotFound extends RuntimeException {

	public AddressNotFound(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	}