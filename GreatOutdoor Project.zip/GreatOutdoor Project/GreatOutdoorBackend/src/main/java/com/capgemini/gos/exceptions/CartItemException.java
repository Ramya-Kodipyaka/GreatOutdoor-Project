package com.capgemini.gos.exceptions;

public class CartItemException extends Exception {
	
	private static final long serialVersionUID = 1L;
	public CartItemException(String msg) {
		super(msg);
	}
	

}
